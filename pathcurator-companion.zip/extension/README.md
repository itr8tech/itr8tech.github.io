# PathCurator Companion (MV3)

Capture pages/links/selections into PathCurator's inbox from anywhere in the browser, and run
**live link audits** from your own browser — real verdicts for intranet links the GitHub Action
reports as "Timed out from CI".

## Install (unpacked, for development/testing)
1. `chrome://extensions` → enable Developer mode → **Load unpacked** → pick this `extension/` folder.
2. The default host (itr8tech.github.io) and localhost work out of the box. For any other app
   address: open **Options** → set the URL → **Save & connect** (this also enables the in-app
   audit bridge for that origin).
3. Optional: open the toolbar popup and flip **Enable link auditing** to grant fetch permission —
   the "Audit now (browser extension)" buttons on the app's #/audit page use it.

## What it can and cannot do
- Captures go through the app's `/add` page into the normal inbox flow — idempotent, works with no
  app tab open.
- Audits return **status metadata only** (status code, redirect origin+path, timing). Response
  bodies never cross the bridge, and redirect URLs are stripped of query strings (SSO tokens).
- The extension stores exactly two things: your app URL and the permission state. No pathway data,
  no tokens.

## Web Store packaging (later)
Zip this folder (`zip -r companion.zip extension`), upload to the Chrome Web Store dashboard as an
unlisted item. Firefox/Safari builds are deferred; the bridge is deliberately compatible (no
`externally_connectable`).
