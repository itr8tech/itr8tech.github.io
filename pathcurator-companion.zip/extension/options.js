// Options: the app origin is USER-CONFIGURED (host-anywhere app — no static matches can know it).
// Save = normalize → permissions.request({origins}) under this user gesture → verify /add/ answers
// → registerContentScripts for that origin (persistent) → store. localhost is static in the
// manifest and skips the grant.
const $ = (id) => document.getElementById(id);
const say = (m) => { $('status').textContent = m; };

document.querySelectorAll('[data-preset]').forEach((b) =>
  b.addEventListener('click', () => { $('app-url').value = b.dataset.preset; }));

(async () => {
  const { appUrl } = await chrome.storage.sync.get({ appUrl: 'https://itr8tech.github.io' });
  $('app-url').value = appUrl;
})();

$('save').addEventListener('click', async () => {
  say('');
  let origin;
  try { origin = new URL($('app-url').value.trim()).origin; }
  catch { say('That is not a valid URL.'); return; }
  const isLocal = /^http:\/\/localhost(:\d+)?$/.test(origin);
  if (!origin.startsWith('https://') && !isLocal) { say('The app URL must be https:// (or localhost for development).'); return; }

  if (!isLocal) {
    const granted = await chrome.permissions.request({ origins: [origin + '/*'] });
    if (!granted) { say('Permission was declined — the audit bridge won’t work on that origin.'); return; }
  }
  try {
    const res = await fetch(origin + '/add/', { method: 'GET', cache: 'no-store' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
  } catch (e) { say(`Could not reach ${origin}/add/ — is the app URL right? (${e.message})`); return; }

  if (!isLocal) {
    try { await chrome.scripting.unregisterContentScripts({ ids: ['pc-bridge'] }); } catch { /* none yet */ }
    await chrome.scripting.registerContentScripts([{
      id: 'pc-bridge', matches: [origin + '/*'], js: ['content-bridge.js'],
      runAt: 'document_start', persistAcrossSessions: true,
    }]);
  }
  await chrome.storage.sync.set({ appUrl: origin });
  say(`Connected to ${origin} ✓`);
});
