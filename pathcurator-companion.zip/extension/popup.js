// Popup: capture the current tab (selection → note) via the background's single capture path
// (one ref per capture; Save disables after first click), plus the audit-permission toggle —
// permissions.request MUST happen here (extension UI user gesture; a page-triggered request from
// the SW is not a gesture).
const $ = (id) => document.getElementById(id);
const BROAD = { origins: ['http://*/*', 'https://*/*'] };

(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  $('url').textContent = tab?.url || '';
  if (tab?.title) $('title').textContent = `Save: ${tab.title.slice(0, 60)}`;
  try {
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: () => String(getSelection()) });
    if (r?.result?.trim()) $('note').value = r.result.trim().slice(0, 500);
  } catch { /* restricted page (chrome://, store) — no selection prefill */ }

  const { appUrl } = await chrome.storage.sync.get({ appUrl: 'https://itr8tech.github.io' });
  $('app').textContent = new URL(appUrl).host;

  $('save').addEventListener('click', async () => {
    $('save').disabled = true;
    const res = await chrome.runtime.sendMessage({ type: 'pc-capture', payload: {
      url: tab?.url, title: tab?.title || null, note: $('note').value.trim() || null } });
    $('status').textContent = res?.ok ? 'Saved ✓' : 'Could not save';
    if (res?.ok) setTimeout(() => window.close(), 700);
    else $('save').disabled = false;
  });

  $('audit-perm').checked = await chrome.permissions.contains(BROAD);
  $('audit-perm').addEventListener('change', async (e) => {
    if (e.target.checked) e.target.checked = await chrome.permissions.request(BROAD);
    else await chrome.permissions.remove(BROAD);
  });

  $('options').addEventListener('click', (e) => { e.preventDefault(); chrome.runtime.openOptionsPage(); });
})();
