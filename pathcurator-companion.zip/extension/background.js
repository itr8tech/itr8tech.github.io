// PathCurator Companion — MV3 service worker.
// CAPTURE: context menus + popup route through the app's /add endpoint (the designed DB-free
// transport: app-origin outbox → inbox drain). One ref per capture EVENT → idempotent.
// AUDIT: fetches URL batches on behalf of the app page (bridged via content-bridge.js) and returns
// METADATA ONLY — status/redirect-origin+path/timing. Never response bodies or headers, and
// redirect finalUrls are stripped of query+fragment (intranet SSO redirects carry tokens).
// Batches are page-driven and small (MV3 SW lifetime: each chunk is one short event).

const DEFAULT_APP = 'https://itr8tech.github.io';
const CHUNK_CAP = 60;              // per audit request (the app sends ~40)
const HOST_CONCURRENCY = 6;        // distinct hosts in flight
const HOST_DELAY = 150;            // ms between same-host requests
const FETCH_TIMEOUT = 12000;
const HEAD_RETRY = new Set([400, 403, 405, 406, 501]);
const COOLDOWN_MS = 1500;          // min gap between chunk starts (shared-origin abuse damper)

const getAppUrl = async () => (await chrome.storage.sync.get({ appUrl: DEFAULT_APP })).appUrl;

// ---------------- capture ----------------
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({ id: 'pc-save-page', title: 'Save page to PathCurator', contexts: ['page'] });
  chrome.contextMenus.create({ id: 'pc-save-link', title: 'Save link to PathCurator', contexts: ['link'] });
  chrome.contextMenus.create({ id: 'pc-save-selection', title: 'Save selection to PathCurator', contexts: ['selection'] });
});

async function openCapture({ url, title = null, note = null }) {
  if (!url || !/^https?:/i.test(url)) return null;
  const app = (await getAppUrl()).replace(/\/+$/, '');
  const p = new URLSearchParams({ url, source: 'extension', popup: '1', ref: `ext:${crypto.randomUUID()}` });
  if (title) p.set('title', title);
  if (note) p.set('note', note);
  const target = `${app}/add/?${p}`;
  try { await chrome.windows.create({ url: target, type: 'popup', width: 430, height: 400, focused: false }); }
  catch { await chrome.tabs.create({ url: target, active: false }); }
  return target;
}

async function onMenu(info, tab) {
  if (info.menuItemId === 'pc-save-link') return openCapture({ url: info.linkUrl, title: info.selectionText || null });
  if (info.menuItemId === 'pc-save-selection') return openCapture({ url: tab?.url, title: tab?.title || null, note: info.selectionText || null });
  return openCapture({ url: tab?.url || info.pageUrl, title: tab?.title || null });
}
chrome.contextMenus.onClicked.addListener(onMenu);
globalThis.__pcTestCapture = onMenu;               // test hook (real right-clicks aren't drivable)

// ---------------- audit checker (port of audit/audit.mjs core) ----------------
function classify(status) {
  if (status >= 200 && status < 300) return { available: 1, statusLabel: 'OK', requiresAuth: 0 };
  if (status >= 300 && status < 400) return { available: 1, statusLabel: 'Redirected', requiresAuth: 0 };
  if (status === 401 || status === 403) return { available: 0, statusLabel: 'Auth required', requiresAuth: 1 };
  if (status === 404 || status === 410) return { available: 0, statusLabel: 'Not found', requiresAuth: 0 };
  if (status >= 500) return { available: 0, statusLabel: 'Server error', requiresAuth: 0 };
  return { available: 0, statusLabel: 'Blocked', requiresAuth: 0 };
}
const stripQuery = (u) => { try { const x = new URL(u); x.search = ''; x.hash = ''; return x.href; } catch { return null; } };

async function tryFetch(url, method) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), FETCH_TIMEOUT);
  try {
    const res = await fetch(url, { method, redirect: 'follow', signal: ctrl.signal, credentials: 'omit', cache: 'no-store' });
    return { status: res.status, redirected: res.redirected, finalUrl: res.url, failed: false, timedOut: false };
  } catch (e) {
    return { failed: true, timedOut: e?.name === 'AbortError', error: String(e?.message || e) };
  } finally { clearTimeout(timer); }
}
async function check(url) {
  const started = Date.now();
  let r = await tryFetch(url, 'HEAD');
  if (r.failed || HEAD_RETRY.has(r.status)) {
    const g = await tryFetch(url, 'GET');
    if (!g.failed) r = g; else if (r.failed) r = g;
  }
  const durationMs = Date.now() - started;
  if (r.failed) {
    return { available: 0, httpStatus: null, statusLabel: r.timedOut ? 'Timeout' : 'Blocked', redirectUrl: null,
      requiresAuth: 0, checkError: (r.error || '').slice(0, 200), checkedAt: Date.now(), durationMs };
  }
  const c = classify(r.status);
  const final = r.redirected ? stripQuery(r.finalUrl) : null;              // METADATA ONLY, token-safe
  return { available: c.available, httpStatus: r.status, statusLabel: c.statusLabel,
    redirectUrl: final && final !== stripQuery(url) ? final : null, requiresAuth: c.requiresAuth,
    checkError: null, checkedAt: Date.now(), durationMs };
}

// Per-host serial, few hosts in parallel — same politeness shape as the Action's checker.
async function checkBatch(items) {
  const byHost = new Map();
  for (const it of items) {
    let host; try { host = new URL(it.url).hostname; } catch { host = it.url; }
    if (!byHost.has(host)) byHost.set(host, []);
    byHost.get(host).push(it);
  }
  const hosts = [...byHost.keys()];
  let hi = 0;
  const results = {};
  await Promise.all(Array.from({ length: Math.min(HOST_CONCURRENCY, hosts.length) }, async () => {
    while (hi < hosts.length) {
      const list = byHost.get(hosts[hi++]);
      for (let i = 0; i < list.length; i++) {
        results[list[i].url_norm] = await check(list[i].url);
        if (i < list.length - 1) await new Promise((res) => setTimeout(res, HOST_DELAY));
      }
    }
  }));
  return results;
}

// ---------------- messaging (from the content bridge + popup) ----------------
let auditBusy = false;
let lastAuditStart = 0;
const okUrl = (u) => { try { const x = new URL(u); return (x.protocol === 'http:' || x.protocol === 'https:') && !x.username && !x.password; } catch { return false; } };

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.type === 'pc-ping') {
    chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] })
      .then((auditReady) => sendResponse({ type: 'pc-pong', version: chrome.runtime.getManifest().version, auditReady }));
    return true;
  }
  if (msg?.type === 'pc-capture') {                 // from the popup
    openCapture(msg.payload || {}).then((t) => sendResponse({ ok: !!t, target: t }));
    return true;
  }
  if (msg?.type === 'pc-audit') {
    (async () => {
      const urls = Array.isArray(msg.urls) ? msg.urls : [];
      if (!urls.length || urls.length > CHUNK_CAP) return { error: `Batch must be 1–${CHUNK_CAP} URLs.`, results: {} };
      if (auditBusy) return { error: 'An audit batch is already running.', results: {} };
      const wait = COOLDOWN_MS - (Date.now() - lastAuditStart);
      if (wait > 0) await new Promise((res) => setTimeout(res, wait));
      auditBusy = true; lastAuditStart = Date.now();
      try {
        const items = urls.filter((it) => it && typeof it.url_norm === 'string' && okUrl(it.url));
        const auditReady = await chrome.permissions.contains({ origins: ['http://*/*', 'https://*/*'] });
        return { results: await checkBatch(items), auditReady };
      } finally { auditBusy = false; }
    })().then(sendResponse);
    return true;
  }
  return false;
});
