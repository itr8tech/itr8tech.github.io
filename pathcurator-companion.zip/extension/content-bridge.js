// PathCurator Companion — content bridge. Injected ONLY on the app's own origins (localhost is
// static; user-configured origins are registered dynamically from the options page). Relays
// window.postMessage ⇄ extension messaging with strict checks: same-window source, same-origin,
// nonce echoed. Announces itself unsolicited so the app never has to know an extension ID.
(() => {
  const ORIGIN = location.origin;
  const post = (m) => window.postMessage(m, ORIGIN);

  const pong = async (nonce) => {
    try {
      const r = await chrome.runtime.sendMessage({ type: 'pc-ping' });
      post({ pc: 'ext-pong', nonce: nonce ?? null, version: r?.version ?? null, auditReady: !!r?.auditReady });
    } catch { /* extension reloading — stay silent */ }
  };

  window.addEventListener('message', async (ev) => {
    if (ev.source !== window || ev.origin !== ORIGIN) return;
    const d = ev.data;
    if (!d || typeof d !== 'object') return;
    if (d.pc === 'ext-ping') { pong(d.nonce); return; }
    if (d.pc === 'ext-audit') {
      try {
        const r = await chrome.runtime.sendMessage({ type: 'pc-audit', urls: d.urls });
        post({ pc: 'ext-audit-result', nonce: d.nonce ?? null, ok: !r?.error, error: r?.error ?? null, results: r?.results ?? {}, auditReady: r?.auditReady !== false });
      } catch (e) {
        post({ pc: 'ext-audit-result', nonce: d.nonce ?? null, ok: false, error: String(e?.message || e), results: {} });
      }
    }
  });

  // Unsolicited announce (the app may not have its listener up yet — it also pings on demand).
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => pong(null), { once: true });
  else pong(null);
})();
